<?php
$razor_api_key = "rzp_test_2lYwrSMlEWNR2V";
?>