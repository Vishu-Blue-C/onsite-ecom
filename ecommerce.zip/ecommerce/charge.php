<?php
if ($_POST) {
	$razorpay_payment_id = $_POST['razorpay_payment_id'];
	
	echo "Razorpay success ID: ". $razorpay_payment_id;
}
?>

<?php


	include 'includes/session.php';
	$userid=$_SESSION['user'];

	

	

		if ($_POST) {
			$razorpay_payment_id = $_POST['razorpay_payment_id'];
			
			echo "Razorpay success ID: ". $razorpay_payment_id;
		
		
		$date = date('Y-m-d');

		$conn = $pdo->open();

		try{
			
			$stmt = $conn->prepare("INSERT INTO sales (user_id, pay_id, sales_date) VALUES (:user_id, :pay_id, :sales_date)");
			$stmt->execute(['user_id'=>$user['id'], 'pay_id'=>$razorpay_payment_id, 'sales_date'=>$date]);
			$salesid = $conn->lastInsertId();
			
			try{
				$stmt = $conn->prepare("SELECT * FROM cart LEFT JOIN products ON products.id=cart.product_id WHERE user_id=:user_id");
				$stmt->execute(['user_id'=>$user['id']]);

				foreach($stmt as $row){
					$query = mysqli_query($con,"SELECT * from products where $userid='user_id' ");
					$userid2=$query['user_id'];
					$stmt = $conn->prepare("INSERT INTO details (sales_id, product_id, quantity,user_id2,date,pay) VALUES (:sales_id, :product_id, :quantity, :user_id2, :date, :pay)");
					$stmt->execute(['sales_id'=>$salesid, 'product_id'=>$row['product_id'], 'quantity'=>$row['quantity'], 'user_id2'=>$userid2, 'date'=>$date, 'pay'=>$razorpay_payment_id]);
					
				}

				$stmt = $conn->prepare("DELETE FROM cart WHERE user_id=:user_id");
				$stmt->execute(['user_id'=>$user['id']]);

				$_SESSION['success'] = 'Transaction successful. Thank you.';

			}
			catch(PDOException $e){
				$_SESSION['error'] = $e->getMessage();
			}

		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}

		$pdo->close();
	}
	
	header('location: profile.php');
	
?>